let randomize_array6 = document.getElementById("randomize_array_btn");
let sort_btn6 = document.getElementById("sort_btn");
let bars_container6 = document.getElementById("bars_container_count");
let speed6 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange6 = 1;
let maxRange6 = 20;
let numOfBars6 = 20;
let heightFactor6 = 4;
let speedFactor6 = 100;
let unsorted_array6 = new Array(numOfBars6);


function addEventListener() {
  numOfBars6 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container6.innerHTML = "";
  unsorted_array6 = createRandomArray6();
  renderBars6(unsorted_array6);
};

speed6.addEventListener("change", (e) => {
  speedFactor6 = parseInt(e.target.value);
});

function randomNum6(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray6() 
{
  let array6 = new Array(numOfBars6);
  for (let i = 0; i < numOfBars6; i++) {
    array6[i] = randomNum6(minRange6, maxRange6);
  }

  return array6;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array6 = createRandomArray6();
  renderBars6(unsorted_array6);
});

function renderBars6(array6) {
  for (let i = 0; i < numOfBars6; i++) {
    let bar6 = document.createElement("div");
    bar6.classList.add("bar6");
    bar6.style.height = array6[i] * heightFactor6 + "px";
    bars_container6.appendChild(bar6);
  }
}

randomize_array6.addEventListener("click", function () 
{
  unsorted_array6 = createRandomArray6();
  bars_container6.innerHTML = "";
  renderBars6(unsorted_array6);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function countingSort(inputArr_c) 
{

    let bars06 = document.getElementsByClassName("bar6");
    
    for (let k = 0; k < bars06.length; k++) {
      bars06[k].style.backgroundColor = "GreenYellow";
    }
    var max = Math.max.apply(Math, inputArr_c);
    var min = Math.min.apply(Math, inputArr_c);

    let j = 0;
    let supplementary = [];
    
    for (let i = min; i <= max; i++) {
        supplementary[i] = 0;
    }
    
    for (let i=0; i < inputArr_c.length; i++) {
        supplementary[inputArr_c[i]] += 1;
    }
       
    for (let i = min; i <= max; i++) 
    {
        
        while (supplementary[i] > 0) 
        {
        
            inputArr_c[j] = i;
            supplementary[i] -= 1;
            bars06[j].style.height = i * heightFactor6 + "px";
            bars06[j].style.backgroundColor = "Green";
            
            await sleep(speedFactor6)
            bars06[j].style.backgroundColor = "GreenYellow"; 
            j++;
           
        }
        await sleep(speedFactor6)
       
    }

    // printing sorted
    await sleep(speedFactor6)
    for (let k = 0; k < bars06.length; k++) {
      bars06[k].style.backgroundColor = "GreenYellow";
    }
    return inputArr_c;
}




sort_btn6.addEventListener("click", function () 
{
    countingSort(unsorted_array6);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
