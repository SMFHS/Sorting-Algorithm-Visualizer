let randomize_array7 = document.getElementById("randomize_array_btn");
let sort_btn7 = document.getElementById("sort_btn");
let bars_container7 = document.getElementById("bars_container_bucket");
let speed7 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange7 = 1;
let maxRange7 = 20;
let numOfBars7 = 20;
let heightFactor7 = 4;
let speedFactor7 = 100;
let unsorted_array7 = new Array(numOfBars7);


function addEventListener() {
  numOfBars7 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container7.innerHTML = "";
  unsorted_array7 = createRandomArray7();
  renderBars7(unsorted_array7);
};

speed7.addEventListener("change", (e) => {
  speedFactor7 = parseInt(e.target.value);
});

function randomNum7(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray7() 
{
  let array7 = new Array(numOfBars7);
  for (let i = 0; i < numOfBars7; i++) {
    array7[i] = randomNum7(minRange7, maxRange7);
  }

  return array7;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array7 = createRandomArray7();
  renderBars7(unsorted_array7);
});

function renderBars7(array7) {
  for (let i = 0; i < numOfBars7; i++) {
    let bar7 = document.createElement("div");
    bar7.classList.add("bar7");
    bar7.style.height = array7[i] * heightFactor7 + "px";
    bars_container7.appendChild(bar7);
  }
}

randomize_array7.addEventListener("click", function () 
{
  unsorted_array7 = createRandomArray7();
  bars_container7.innerHTML = "";
  renderBars7(unsorted_array7);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// find the maximum in the array
function getMax1(data1,size1)
{
    let max1 = data1[0];
        for (let i = 1; i < size1; i++)
            if (data1[i] > max1) // if greater
                max1 = data1[i]
        return max1 //return the max
}

// get the minimum in the array
function getMin1(data1, n1)
{
    let min1 = data1[0];
    for (let i = 1; i < n1; i++)
        if (data1[i] < min1) // if lesser
            min1 = data1[i]
    return min1 //return the min
}

// the main code for the bucket sort
async function bucketSort(inputArr_buc,n)
{

    let bars07 = document.getElementsByClassName("bar7");

    for (let k = 0; k < bars07.length; k++) {
      bars07[k].style.backgroundColor = "GreenYellow";
    }
    // if 1 or no elements
    if (n <= 1)
            return;

    // getting maximun and minimum
    let max = getMax1(inputArr_buc, n)
    let min = getMin1(inputArr_buc, n)

    // for bucket making --- calculating bucket number
    const bucketNo = Math.ceil(Math.log10(n) * 3.3);

    // for finding the interval
    let interval = (max - min) / bucketNo
    
    // creating buckets ---- to avoid loosing any digit adding 1 more bucket
    let createdBucket = bucketNo + 1

   
    // 1) Create n empty buckets equal to the number calculated      
    let buckets = new Array(createdBucket);

    for (let i = 0; i < createdBucket; i++)
    {
        buckets[i] = [];
    }

    // 2) Put array elements in different buckets
    for (let i = 0; i <  n;  i++) {
        // identifying the bucket
        buckets[Math.floor ( Math.abs((inputArr_buc[i] - min) / interval )) ].push(inputArr_buc[i]);
        
        // display one bucket updated
    }

    // 3) Sort individual buckets by the insrtion sort 
    for (let i = 0; i < createdBucket; i++) {
        buckets[i].sort(function(a,b){return a-b;});
    }

    // 4) Concatenate all buckets into arr[] to get the sorted array
    let index = 0;
    let temp = 0;
    for (let i = 0; i < createdBucket; i++) 
    {
        for (let j = 0; j < buckets[i].length; j++) 
        {
          temp = index;
          bars07[index].style.height = buckets[i][j] * heightFactor7 + "px";
          bars07[index].style.backgroundColor = "Green";
          inputArr_buc[index++] = buckets[i][j];
          await sleep(speedFactor7);
          bars07[temp].style.backgroundColor = "GreenYellow";
        }
                // the changed graphs after sorting iteration
    }
    await sleep(speedFactor7);
    await sleep(speedFactor6)
    for (let k = 0; k < bars07.length; k++) {
      bars07[k].style.backgroundColor = "GreenYellow";
    }
}





sort_btn7.addEventListener("click", function () 
{
    bucketSort(unsorted_array7, unsorted_array7.length);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
