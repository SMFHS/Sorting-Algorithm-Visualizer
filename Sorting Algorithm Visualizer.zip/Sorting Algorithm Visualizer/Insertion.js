let randomize_array1 = document.getElementById("randomize_array_btn");
let sort_btn1 = document.getElementById("sort_btn");
let bars_container1 = document.getElementById("bars_container_insertion");
let speed1 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange1 = 1;
let maxRange1 = 20;
let numOfBars1 = 20;
let heightFactor1 = 4;
let speedFactor1 = 100;
let unsorted_array1 = new Array(numOfBars1);



function addEventListener() {
  numOfBars1 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container1.innerHTML = "";
  unsorted_array1 = createRandomArray1();
  renderBars1(unsorted_array1);
};

speed1.addEventListener("change", (e) => {
  speedFactor1 = parseInt(e.target.value);
});

function randomNum1(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray1() 
{
  let array1 = new Array(numOfBars1);
  for (let i = 0; i < numOfBars1; i++) {
    array1[i] = randomNum1(minRange1, maxRange1);
  }

  return array1;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array1 = createRandomArray1();
  renderBars1(unsorted_array1);
});

function renderBars1(array1) {
  for (let i = 0; i < numOfBars1; i++) {
    let bar1 = document.createElement("div");
    bar1.classList.add("bar1");
    bar1.style.height = array1[i] * heightFactor1 + "px";
    bars_container1.appendChild(bar1);
  }
}

randomize_array1.addEventListener("click", function () 
{
  unsorted_array1 = createRandomArray1();
  bars_container1.innerHTML = "";
  renderBars1(unsorted_array1);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function insertionSort(array1) {
  let bars01 = document.getElementsByClassName("bar1");
  for (let i = 1; i < array1.length; i++) {
    let key = array1[i];
    let j;
    
    for (j = i - 1; j >= 0 && array1[j] > key; j--) 

    {
      array1[j + 1] = array1[j];
      bars01[j + 1].style.height = array1[j + 1] * heightFactor1 + "px";
      bars01[j + 1].style.backgroundColor = "DeepPink";
      //bars[j + 1].innerText = array[j + 1];
      await sleep(speedFactor1);

      for (let k = 0; k < bars01.length; k++) 
      {
        if (k != j + 1)
        {
          bars01[k].style.backgroundColor = "pink";
        }
      }
  
    }
    array1[j + 1] = key;
    bars01[j + 1].style.height = array1[j + 1] * heightFactor1 + "px";
    bars01[j + 1].style.backgroundColor = "pink";
    //bars[j + 1].innerText = array[j + 1];
    await sleep(speedFactor1);
  }

  for (let k = 0; k < bars01.length; k++) {
    bars01[k].style.backgroundColor = "pink";
  }
  return array1;
}

sort_btn1.addEventListener("click", function () 
{
    insertionSort(unsorted_array1);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
