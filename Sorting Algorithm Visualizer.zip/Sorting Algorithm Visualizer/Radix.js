let randomize_array8 = document.getElementById("randomize_array_btn");
let sort_btn8 = document.getElementById("sort_btn");
let bars_container8 = document.getElementById("bars_container_radix");
let speed8 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange8 = 1;
let maxRange8 = 20;
let numOfBars8 = 20;
let heightFactor8 = 4;
let speedFactor8 = 100;
let unsorted_array8 = new Array(numOfBars8);



function addEventListener() {
  numOfBars8 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container8.innerHTML = "";
  unsorted_array8 = createRandomArray8();
  renderBars8(unsorted_array8);
};

speed8.addEventListener("change", (e) => {
  speedFactor8 = parseInt(e.target.value);
});

function randomNum8(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray8() 
{
  let array8 = new Array(numOfBars8);
  for (let i = 0; i < numOfBars8; i++) {
    array8[i] = randomNum8(minRange8, maxRange8);
  }

  return array8;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array8 = createRandomArray8();
  renderBars8(unsorted_array8);
});

function renderBars8(array8) {
  for (let i = 0; i < numOfBars8; i++) {
    let bar8 = document.createElement("div");
    bar8.classList.add("bar8");
    bar8.style.height = array8[i] * heightFactor8 + "px";
    bars_container8.appendChild(bar8);
  }
}

randomize_array8.addEventListener("click", function () 
{
  unsorted_array8 = createRandomArray8();
  bars_container8.innerHTML = "";
  renderBars8(unsorted_array8);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

//   find the maximum in the array
function getMax(data,size)
{
    let max = data[0];
        for (let i = 1; i < size; i++)
            if (data[i] > max) // if greater
                max = data[i]
        return max //return the max
}

// for getting a digit at a specified place
function getDigit(num, place) {
    return Math.floor(Math.abs(num) / Math.pow(10, place)) % 10 //the digit we need
    }

// A function to do counting sort of arr[] according to
    // the digit represented by exp.
async function radixSort(dataArray) 
{
  let x = dataArray;
    let bars08 = document.getElementsByClassName("bar8");
  
    for (let k = 0; k < bars08.length; k++) {
      bars08[k].style.backgroundColor = "GreenYellow";
    }
    const max = getMax(dataArray, dataArray.length)
    
    // count -- iterate equal to digits of max
    // go till max/mutilple of 10, i.e 10, 100 result greater than 0
    //  99 then 2 times ,9999 the 4 times
    for (let place = 1, i = 0; Math.floor(max/ place) > 0; place *= 10, i++)
    {
        // making buckets as digits thus 10 buckets 
        let buckets = Array.from({length: 10}, () => [])
        
        // checking from the least bit that which digit will be included where and so on
        for (let j = 0 ; j < dataArray.length ; j++)
        {
            buckets[getDigit(dataArray[j] , i)].push(dataArray[j])
        }
        
        dataArray = [].concat(...buckets)

        // the changed graphs after sorting iteration
        
    }

    
    for(let i = dataArray.length - 1 ; i>= 0; i--)
    {
      for(let j = 0; j<dataArray.length; j++)
      {
          if(dataArray[j]==x[i])
          {
            bars08[j].style.height = dataArray[j] * heightFactor8 + "px";
            bars08[j].style.backgroundColor = "Green";
            await sleep(speedFactor8);
          }
          bars08[j].style.backgroundColor = "GreenYellow";
      }
    }
    await sleep(speedFactor8);

    for (let k = 0; k < bars08.length; k++) {
      bars08[k].style.backgroundColor = "GreenYellow";
    }
}
    

sort_btn8.addEventListener("click", function () 
{
  radixSort(unsorted_array8);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
