let randomize_array4 = document.getElementById("randomize_array_btn");
let sort_btn4 = document.getElementById("sort_btn");
let bars_container4 = document.getElementById("bars_container_heap");
let speed4 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange4 = 1;
let maxRange4 = 20;
let numOfBars4 = 20;
let heightFactor4 = 4;
let speedFactor4 = 100;
let unsorted_array4 = new Array(numOfBars4);



function addEventListener() {
  numOfBars4 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container4.innerHTML = "";
  unsorted_array4 = createRandomArray4();
  renderBars4(unsorted_array4);
};

speed4.addEventListener("change", (e) => {
  speedFactor4 = parseInt(e.target.value);
});

function randomNum4(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray4() 
{
  let array4 = new Array(numOfBars4);
  for (let i = 0; i < numOfBars4; i++) {
    array4[i] = randomNum4(minRange4, maxRange4);
  }

  return array4;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array4 = createRandomArray4();
  renderBars4(unsorted_array4);
});

function renderBars4(array4) {
  for (let i = 0; i < numOfBars4; i++) {
    let bar4 = document.createElement("div");
    bar4.classList.add("bar4");
    bar4.style.height = array4[i] * heightFactor4 + "px";
    bars_container4.appendChild(bar4);
  }
}

randomize_array4.addEventListener("click", function () 
{
  unsorted_array4 = createRandomArray4();
  bars_container4.innerHTML = "";
  renderBars4(unsorted_array4);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function HeapSort(array4) {
    let bars04 = document.getElementsByClassName("bar4");
    for (let i = Math.floor(array4.length / 2); i >= 0; i--) {
      await heapify(array4, array4.length, i);
    }
    for (let i = array4.length - 1; i >= 0; i--) {
      await swap2(array4, 0, i, bars04);
      await heapify(array4, i, 0);
    }
    for (let k = 0; k < bars04.length; k++) {
      bars04[k].style.backgroundColor = "yellow";
      await sleep(speedFactor4);
    }
    return array4;
  }

  async function heapify(array4, n, i) {
    let bars04 = document.getElementsByClassName("bar4");
    let largest = i;
    let left = 2 * i + 1;
    let right = 2 * i + 2;
    if (left < n && array4[left] > array4[largest]) {
      largest = left;
    }
    if (right < n && array4[right] > array4[largest]) {
      largest = right;
    }
    if (largest != i) {
      await swap2(array4, i, largest, bars04);
      await heapify(array4, n, largest);
    }
  }

  async function swap2(array4, i, j, bars04) {
    let temp = array4[i];
    array4[i] = array4[j];
    array4[j] = temp;
    bars04[i].style.height = array4[i] * heightFactor4 + "px";
    bars04[j].style.height = array4[j] * heightFactor4 + "px";
    bars04[i].style.backgroundColor = "GoldenRod";
    bars04[j].style.backgroundColor = "GoldenRod";
    await sleep(speedFactor4);
  
    for (let k = 0; k < bars04.length; k++) {
      if (k != i && k != j) {
        bars04[k].style.backgroundColor = "yellow";
      }
    }
    //bars[i].innerText = array[i];
    //bars[j].innerText = array[j];
    return array4;
  }
  

sort_btn4.addEventListener("click", function () 
{
    HeapSort(unsorted_array4);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
