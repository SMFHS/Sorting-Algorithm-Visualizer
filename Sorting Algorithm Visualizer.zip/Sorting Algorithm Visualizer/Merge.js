let randomize_array3 = document.getElementById("randomize_array_btn");
let sort_btn3 = document.getElementById("sort_btn");
let bars_container3 = document.getElementById("bars_container_merge");
let speed3 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange3 = 1;
let maxRange3 = 20;
let numOfBars3 = 20;
let heightFactor3 = 4;
let speedFactor3 = 100;
let unsorted_array3 = new Array(numOfBars3);


function addEventListener() {
  numOfBars3 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container3.innerHTML = "";
  unsorted_array3 = createRandomArray3();
  renderBars3(unsorted_array3);
};

speed3.addEventListener("change", (e) => {
  speedFactor3 = parseInt(e.target.value);
});

function randomNum3(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray3() 
{
  let array3 = new Array(numOfBars3);
  for (let i = 0; i < numOfBars3; i++) {
    array3[i] = randomNum3(minRange3, maxRange3);
  }

  return array3;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array3 = createRandomArray3();
  renderBars3(unsorted_array3);
});

function renderBars3(array3) {
  for (let i = 0; i < numOfBars3; i++) {
    let bar3 = document.createElement("div");
    bar3.classList.add("bar3");
    bar3.style.height = array3[i] * heightFactor3 + "px";
    bars_container3.appendChild(bar3);
  }
}

randomize_array3.addEventListener("click", function () 
{
  unsorted_array3 = createRandomArray3();
  bars_container3.innerHTML = "";
  renderBars3(unsorted_array3);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function mergeSort(arr) {
    let bars3 = document.getElementsByClassName("bar3");
    if (arr.length < 2) {
      return arr;
    }
    const middle = Math.floor(arr.length / 2);
    const left = arr.slice(0, middle);
    const right = arr.slice(middle);
    let actualHalf = await mergeSort(left);
    await mergeSort(right);
  
    let i = 0;
    let j = 0;
    let k = 0;
  
    while (i < left.length && j < right.length) {
      if (left[i] < right[j]) {
        arr[k] = left[i];
        i++;
        // bars[k].style.height = arr[k] * heightFactor + "px";
        // bars[k].style.backgroundColor = "lightgreen";
        // bars[k].innerText = arr[k];
        //await sleep(speedFactor);
      } else {
        arr[k] = right[j];
        j++;
        // bars[k + middle].style.height = arr[k] * heightFactor + "px";
        // bars[k + middle].style.backgroundColor = "yellow";
        // bars[k].innerText = arr[k];
        //await sleep(speedFactor);
      }
      //shift to right side
      //console.log(k);
      //bars[k].style.height = arr[k] * heightFactor + "px";
      //bars[k].style.backgroundColor = "lightgreen";
  
      // bars[k + middle].style.height = arr[k] * heightFactor + "px";
      // bars[k + middle].style.backgroundColor = "yellow";
  
      //visualize it for right and left side
      bars3[k].style.height = arr[k] * heightFactor3 + "px";
      bars3[k].style.backgroundColor = "GoldenRod";
      if (k + arr.length < bars3.length) {
        bars3[k + arr.length].style.height = arr[k] * heightFactor3 + "px";
        console.log(arr[k] * heightFactor3);
        bars3[k + arr.length].style.backgroundColor = "yellow";
      }
      await sleep(speedFactor3);
      //bars[k].innerText = arr[k];
  
      k++;
    }
  
    while (i < left.length) {
      arr[k] = left[i];
      bars3[k].style.height = arr[k] * heightFactor3 + "px";
      bars3[k].style.backgroundColor = "GoldenRod";
      await sleep(speedFactor3);
      i++;
      k++;
    }
  
    while (j < right.length) {
      arr[k] = right[j];
      bars3[k].style.height = arr[k] * heightFactor3 + "px";
      bars3[k].style.backgroundColor = "GoldenRod";
      await sleep(speedFactor3);
      j++;
      k++;
    }
  
    // for (let i = 0; i < arr.length; i++) {
    //   bars[i].style.height = arr[i] * heightFactor + "px";
    //   bars[i].style.backgroundColor = "lightgreen";
    //   await sleep(speedFactor);
    // }
  
    for (let k = 0; k < bars3.length; k++) {
      bars3[k].style.backgroundColor = "yellow";
    }
  
    return arr;
  }
  
function mergeSortD(arr, start, end) {
    if (arr.length < 2) {
      return arr;
    }
  
    let middle = Math.floor((start + end) / 2);
    let left = arr.slice(start, middle);
    let right = arr.slice(middle, end);
  
    //mergeSort(left);
    mergeSort(right);
  }


sort_btn3.addEventListener("click", function () 
{
    mergeSort(unsorted_array3);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
