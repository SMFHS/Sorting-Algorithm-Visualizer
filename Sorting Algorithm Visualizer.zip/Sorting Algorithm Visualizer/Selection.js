let randomize_array5 = document.getElementById("randomize_array_btn");
let sort_btn5 = document.getElementById("sort_btn");
let bars_container5 = document.getElementById("bars_container_selection");
let speed5 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange5 = 1;
let maxRange5 = 20;
let numOfBars5 = 20;
let heightFactor5 = 4;
let speedFactor5 = 100;
let unsorted_array5 = new Array(numOfBars5);


function addEventListener() {
  numOfBars5 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container5.innerHTML = "";
  unsorted_array5 = createRandomArray5();
  renderBars5(unsorted_array5);
};

speed5.addEventListener("change", (e) => {
  speedFactor5 = parseInt(e.target.value);
});

function randomNum5(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray5() 
{
  let array5 = new Array(numOfBars5);
  for (let i = 0; i < numOfBars5; i++) {
    array5[i] = randomNum(minRange5, maxRange5);
  }

  return array5;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array5 = createRandomArray5();
  renderBars5(unsorted_array5);
});

function renderBars5(array5) {
  for (let i = 0; i < numOfBars5; i++) {
    let bar5 = document.createElement("div");
    bar5.classList.add("bar5");
    bar5.style.height = array5[i] * heightFactor5 + "px";
    bars_container5.appendChild(bar5);
  }
}

randomize_array5.addEventListener("click", function () 
{
  unsorted_array5 = createRandomArray5();
  bars_container5.innerHTML = "";
  renderBars5(unsorted_array5);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function selectionSort(Arr5) 
{
    let bars05 = document.getElementsByClassName("bar5");
    let n = Arr5.length;

    for (let k = 0; k < bars05.length; k++) {
      bars05[k].style.backgroundColor = "yellow";
    }
  
    for (let i = 0; i < n; i++) 
    {
      // Finding the smallest number in the subarray
      let min = i;
      for (let j = i + 1; j < n; j++) 
      {
        if (Arr5[j] < Arr5[min]) 
        {
          min = j;
          bars05[min].style.backgroundColor = "GoldenRod";
        }
      }
      if (min != i) 
      {
        // Swapping the elements
        let tmp = Arr5[i];
        Arr5[i] = Arr5[min];
        bars05[i].style.height = Arr5[i] * heightFactor5 + "px";
        bars05[i].style.backgroundColor = "yellow";

        await sleep(speedFactor5)
        
        Arr5[min] = tmp;
        bars05[min].style.height = tmp * heightFactor5 + "px";
        bars05[min].style.backgroundColor = "yellow";

        await sleep(speedFactor5)
      }
    }
    for (let k = 0; k < bars05.length; k++) {
      bars05[k].style.backgroundColor = "yellow";
    }
}
sort_btn5.addEventListener("click", function () 
{
    selectionSort(unsorted_array5);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
