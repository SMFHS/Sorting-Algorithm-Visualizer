let randomize_array2 = document.getElementById("randomize_array_btn");
let sort_btn2 = document.getElementById("sort_btn");
let bars_container2 = document.getElementById("bars_container_quicksort");
let speed2 = document.getElementById("speed");
//let slider = document.getElementById("slider");
let minRange2 = 1;
let maxRange2 = 20;
let numOfBars2 = 20;
let heightFactor2 = 4;
let speedFactor2 = 100;
let unsorted_array2 = new Array(numOfBars2);



function addEventListener() {
  numOfBars2 = 20;
  //maxRange = slider.value;
  //console.log(numOfBars);
  bars_container2.innerHTML = "";
  unsorted_array2 = createRandomArray2();
  renderBars2(unsorted_array2);
};

speed2.addEventListener("change", (e) => {
  speedFactor2 = parseInt(e.target.value);
});

function randomNum2(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createRandomArray2() 
{
  let array2 = new Array(numOfBars2);
  for (let i = 0; i < numOfBars2; i++) {
    array2[i] = randomNum2(minRange2, maxRange2);
  }

  return array2;
}

document.addEventListener("DOMContentLoaded", function () {
  unsorted_array2 = createRandomArray2();
  renderBars2(unsorted_array2);
});

function renderBars2(array2) {
  for (let i = 0; i < numOfBars2; i++) {
    let bar2 = document.createElement("div");
    bar2.classList.add("bar2");
    bar2.style.height = array2[i] * heightFactor2 + "px";
    bars_container2.appendChild(bar2);
  }
}

randomize_array2.addEventListener("click", function () 
{
  unsorted_array2 = createRandomArray2();
  bars_container2.innerHTML = "";
  renderBars2(unsorted_array2);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function swap(items, leftIndex, rightIndex, bars02) {
  var temp = items[leftIndex];
  items[leftIndex] = items[rightIndex];
  items[rightIndex] = temp;
  bars02[leftIndex].style.height = items[leftIndex] * heightFactor2 + "px";
  bars02[leftIndex].style.backgroundColor = "DeepPink";
  //bars[leftIndex].innerText = items[leftIndex];
  bars02[rightIndex].style.height = items[rightIndex] * heightFactor2 + "px";
  bars02[rightIndex].style.backgroundColor = "DeepPink";
  //bars[rightIndex].innerText = items[rightIndex];
  await sleep(speedFactor2);
}

async function partition(items, left, right) {
  let bars02 = document.getElementsByClassName("bar2");
  let pivotIndex = Math.floor((right + left) / 2);
  var pivot = items[pivotIndex]; //middle element
  bars02[pivotIndex].style.backgroundColor = "DeepPink";

  for (let i = 0; i < bars02.length; i++) {
    if (i != pivotIndex) {
      bars02[i].style.backgroundColor = "pink";
    }
  }

  (i = left), //left pointer
    (j = right); //right pointer
  while (i <= j) {
    while (items[i] < pivot) {
      i++;
    }
    while (items[j] > pivot) {
      j--;
    }
    if (i <= j) {
      await swap(items, i, j, bars02); //sawpping two elements
      i++;
      j--;
    }
  }
  return i;
}

async function quickSort(items, left, right) {
    var index;
    let bars02 = document.getElementsByClassName("bar2");
    if (items.length > 1) {
      index = await partition(items, left, right); //index returned from partition
      if (left < index - 1) {
        //more elements on the left side of the pivot
        await quickSort(items, left, index - 1);
      }
      if (index < right) {
        //more elements on the right side of the pivot
        await quickSort(items, index, right);
      }
    }
  
    for (let i = 0; i < bars02.length; i++) {
      bars02[i].style.backgroundColor = "pink";
    }


    return items;
  }
  

sort_btn2.addEventListener("click", function () 
{
  console.log(unsorted_array2.length);

      quickSort(unsorted_array2, 0, unsorted_array2.length - 1);
  /*switch (algotouse) {
    case "bubble":
      bubbleSort(unsorted_array);
      break;
    case "insertion":
      InsertionSort(unsorted_array);
      break;
    case "quick":
      console.log(unsorted_array.length);
      quickSort(unsorted_array, 0, unsorted_array.length - 1);
      break;
    default:
      bubbleSort(unsorted_array);
      break;
  }*/
});
